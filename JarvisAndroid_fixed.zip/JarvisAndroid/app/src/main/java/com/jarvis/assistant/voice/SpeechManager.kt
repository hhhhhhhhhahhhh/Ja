package com.jarvis.assistant.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class SpeechManager(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var turkishVoices: List<android.speech.tts.Voice> = emptyList()
    private var voiceIndex = 0

    private val mainHandler = Handler(Looper.getMainLooper())

    // Background "Jarvis" wake-word listening.
    private var continuousMode = false
    private var isListeningNow = false
    private var isSpeakingNow = false
    private var isSessionStarting = false
    private var consecutiveErrorCount = 0

    // A one-off push-to-talk session takes priority over the wake-word loop
    // for the duration of a single recognition, then hands control back.
    private var isPushToTalkSession = false
    private var pushToTalkOnResult: ((String) -> Unit)? = null
    private var pushToTalkOnListening: ((Boolean) -> Unit)? = null
    private var pushToTalkOnError: ((String) -> Unit)? = null
    // The very first recognition pass after a period of silence is often cut
    // short by the OS before the user has actually started speaking. Instead
    // of immediately telling the user "didn't hear you" on a no-match/timeout,
    // retry silently once before giving up.
    private var pushToTalkRetriesLeft = 0

    // Which recognition backend got selected (Google's app vs whatever the
    // OS considers "default"). Surfaced in error messages for diagnosis —
    // many OEM ROMs (MIUI included) ship a non-functional "default" recognizer.
    private var lastRecognizerSource = "UNKNOWN"

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var focusRequest: AudioFocusRequest? = null
    private val noopFocusListener = AudioManager.OnAudioFocusChangeListener { /* we don't need to react */ }

    // Callbacks used by the background wake-word listening mode.
    private var onWakeResult: ((String) -> Unit)? = null
    private var onListeningStateChanged: ((Boolean) -> Unit)? = null
    private var onSpeakStateChanged: ((Boolean) -> Unit)? = null
    private var onErrorHeard: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
                turkishVoices = tts.voices
                    ?.filter { it.locale.language == "tr" }
                    ?.sortedBy { it.name }
                    .orEmpty()
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeakingNow = true
                onSpeakStateChanged?.invoke(true)
            }
            override fun onDone(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                abandonDuck()
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
            override fun onError(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                abandonDuck()
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
        })
    }

    /** Cycles to the next available Turkish TTS voice and speaks a short confirmation. */
    fun cycleVoice(): String {
        if (turkishVoices.size <= 1) {
            speak("Bu cihazda değiştirebileceğim başka bir Türkçe ses yok.")
            return "Bu cihazda tek bir Türkçe ses seçeneği var."
        }
        voiceIndex = (voiceIndex + 1) % turkishVoices.size
        tts.voice = turkishVoices[voiceIndex]
        val label = "Ses değiştirildi, seçenek ${voiceIndex + 1} / ${turkishVoices.size}."
        speak(label)
        return label
    }

    /**
     * Starts always-on background listening. [onWakeResult] only fires for
     * utterances that contain the wake word "jarvis" (already stripped out of
     * the text). Every other heard phrase is silently discarded and listening
     * restarts automatically. [initiallyEnabled] lets the caller restore the
     * user's last saved preference without a visible mic flicker.
     */
    fun startContinuousListening(
        initiallyEnabled: Boolean,
        onWakeResult: (String) -> Unit,
        onListeningStateChanged: (Boolean) -> Unit,
        onSpeakStateChanged: (Boolean) -> Unit,
        onErrorHeard: (String) -> Unit
    ) {
        this.onWakeResult = onWakeResult
        this.onListeningStateChanged = onListeningStateChanged
        this.onSpeakStateChanged = onSpeakStateChanged
        this.onErrorHeard = onErrorHeard
        continuousMode = initiallyEnabled
        if (initiallyEnabled) startRecognizerCycle()
    }

    fun stopContinuousListening() {
        continuousMode = false
        isListeningNow = false
        isSessionStarting = false
        unmuteMicBeep()
        abandonDuck()
        recognizer?.stopListening()
    }

    /** Temporarily/permanently turns off the "Jarvis" background listening loop. */
    fun pauseWakeWordListening() {
        continuousMode = false
        if (!isPushToTalkSession) {
            isSessionStarting = false
            isListeningNow = false
            unmuteMicBeep()
            abandonDuck()
            try { recognizer?.stopListening() } catch (e: Exception) { /* ignore */ }
        }
    }

    /** Turns the "Jarvis" background listening loop back on. */
    fun resumeWakeWordListening() {
        if (continuousMode) return
        continuousMode = true
        startRecognizerCycle()
    }

    fun isWakeWordListening(): Boolean = continuousMode

    /**
     * Push-to-talk: a single recognition pass that does NOT require the
     * "Jarvis" wake word — whatever is said is treated as the command. Takes
     * priority over the background wake-word loop for its duration, then
     * hands control back automatically.
     */
    fun listenOnce(
        onResult: (String) -> Unit,
        onListeningStateChanged: (Boolean) -> Unit,
        onError: (String) -> Unit
    ) {
        if (isSpeakingNow) {
            onError("Şu anda konuşuyorum, bitince tekrar dene.")
            return
        }
        if (isListeningNow || isSessionStarting) {
            // Cancel whatever the wake-word loop is doing and take over immediately.
            try { recognizer?.cancel() } catch (e: Exception) { /* ignore */ }
            isListeningNow = false
            isSessionStarting = false
            unmuteMicBeep()
            abandonDuck()
        }
        pushToTalkOnResult = onResult
        pushToTalkOnListening = onListeningStateChanged
        pushToTalkOnError = onError
        pushToTalkRetriesLeft = 1
        isPushToTalkSession = true
        requestDuck()
        muteMicBeep()
        startRecognizerCycle()
    }

    private fun clearPushToTalk() {
        isPushToTalkSession = false
        pushToTalkOnResult = null
        pushToTalkOnListening = null
        pushToTalkOnError = null
    }

    private fun startRecognizerCycle() {
        if ((!continuousMode && !isPushToTalkSession) || isSpeakingNow || isListeningNow || isSessionStarting) return

        // Fail fast with a clear signal instead of silently looping forever on
        // devices/profiles with no speech recognition service available.
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            val message = "Bu cihazda konuşma tanıma servisi bulunamadı."
            if (isPushToTalkSession) {
                val cb = pushToTalkOnError
                clearPushToTalk()
                cb?.invoke(message)
            } else {
                onErrorHeard?.invoke(message)
            }
            return
        }

        isSessionStarting = true

        if (recognizer == null) {
            recognizer = createBestRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1800)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }

        val runningAsPushToTalk = isPushToTalkSession

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListeningNow = true
                isSessionStarting = false
                consecutiveErrorCount = 0
                if (runningAsPushToTalk) pushToTalkOnListening?.invoke(true)
                else onListeningStateChanged?.invoke(true)
            }

            override fun onResults(results: Bundle) {
                isListeningNow = false
                isSessionStarting = false
                abandonDuck()
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                if (runningAsPushToTalk) {
                    pushToTalkOnListening?.invoke(false)
                    val cb = pushToTalkOnResult
                    clearPushToTalk()
                    cb?.invoke(text)
                    if (continuousMode) restartSoon(200)
                } else {
                    onListeningStateChanged?.invoke(false)
                    handleHeardText(text)
                }
            }

            override fun onError(error: Int) {
                isListeningNow = false
                isSessionStarting = false
                unmuteMicBeep()
                abandonDuck()

                if (runningAsPushToTalk) {
                    if ((error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) &&
                        pushToTalkRetriesLeft > 0
                    ) {
                        // Likely started listening a beat too early — try once more
                        // silently instead of surfacing a "didn't hear you" message.
                        pushToTalkRetriesLeft--
                        pushToTalkOnListening?.invoke(false)
                        mainHandler.postDelayed({
                            requestDuck()
                            muteMicBeep()
                            startRecognizerCycle()
                        }, 250)
                        return
                    }
                    pushToTalkOnListening?.invoke(false)
                    val errCb = pushToTalkOnError
                    clearPushToTalk()
                    val src = lastRecognizerSource
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH ->
                            errCb?.invoke("Bir şey duyamadım, tekrar dener misin? (kod: NO_MATCH, motor: $src)")
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            errCb?.invoke("Bir şey duyamadım, tekrar dener misin? (kod: TIMEOUT, motor: $src)")
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            errCb?.invoke("Mikrofon izni verilmediği için dinleyemiyorum. (kod: NO_PERMISSION, motor: $src)")
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            errCb?.invoke("İnternet bağlantısı zayıf olduğu için seni duyamadım, tekrar dener misin? (kod: NETWORK, motor: $src)")
                        SpeechRecognizer.ERROR_SERVER ->
                            errCb?.invoke("Konuşma tanıma servisinde bir sorun oldu, tekrar dener misin? (kod: SERVER, motor: $src)")
                        SpeechRecognizer.ERROR_CLIENT ->
                            errCb?.invoke("Konuşma tanıma servisinde bir sorun oldu, tekrar dener misin? (kod: CLIENT, motor: $src)")
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                            errCb?.invoke("Az önceki dinleme henüz kapanmadı, bir saniye bekleyip tekrar dener misin? (kod: BUSY, motor: $src)")
                        else -> errCb?.invoke("Seni duyamadım, tekrar dener misin? (kod: $error, motor: $src)")
                    }
                    if (continuousMode) restartSoon(200)
                    return
                }

                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        // Normal in always-on mode — just listen again quietly.
                        consecutiveErrorCount = 0
                        restartSoon(150)
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        // Another recognition session is still winding down — back off
                        // a bit longer instead of hammering it.
                        restartSoon(1200)
                    }
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        onErrorHeard?.invoke("Mikrofon izni verilmediği için dinleyemiyorum.")
                    }
                    else -> {
                        consecutiveErrorCount++
                        if (consecutiveErrorCount >= 2) {
                            // The recognizer sometimes gets stuck after a few failures —
                            // recreate it from scratch rather than keep retrying the same instance.
                            recreateRecognizer()
                            consecutiveErrorCount = 0
                        }
                        restartSoon(900)
                    }
                }
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            isSessionStarting = false
            if (runningAsPushToTalk) {
                val errCb = pushToTalkOnError
                clearPushToTalk()
                errCb?.invoke("Dinleme başlatılamadı, tekrar dener misin?")
            } else {
                restartSoon(800)
            }
        }
    }

    private fun recreateRecognizer() {
        try { recognizer?.destroy() } catch (e: Exception) { /* ignore */ }
        recognizer = null
    }

    /**
     * Many phone-maker default speech recognizers (MIUI's own assistant, etc.)
     * silently fail or don't support Turkish well, even when
     * [SpeechRecognizer.isRecognitionAvailable] returns true. If the Google
     * app is installed, target its recognition service explicitly — it's far
     * more reliable — and only fall back to whatever the device considers
     * "default" if Google isn't available.
     */
    private fun createBestRecognizer(): SpeechRecognizer {
        try {
            val pm = context.packageManager
            val matches = pm.queryIntentServices(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0)
            val google = matches.firstOrNull { it.serviceInfo.packageName == "com.google.android.googlequicksearchbox" }
            if (google != null) {
                lastRecognizerSource = "GOOGLE"
                return SpeechRecognizer.createSpeechRecognizer(
                    context,
                    ComponentName(google.serviceInfo.packageName, google.serviceInfo.name)
                )
            }
        } catch (e: Exception) { /* fall through to default below */ }
        lastRecognizerSource = "SYSTEM_DEFAULT"
        return SpeechRecognizer.createSpeechRecognizer(context)
    }

    /**
     * Best-effort suppression of the system recognizer "start/stop listening" beep.
     * On stock Android these tones play on STREAM_MUSIC (not STREAM_SYSTEM), so both
     * are muted here for the widest device coverage. Requires MODIFY_AUDIO_SETTINGS.
     * Note: some OEM skins (e.g. MIUI) add their own separate "mic in use" privacy
     * sound tied to the OS-level privacy indicator — that one lives outside the app
     * and can only be turned off from the phone's own Settings > Privacy menu.
     */
    private fun muteMicBeep() {
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
        } catch (e: Exception) { /* not all devices allow this — safe to ignore */ }
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
        } catch (e: Exception) { /* ignore */ }
    }

    private fun unmuteMicBeep() {
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) { /* ignore */ }
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) { /* ignore */ }
    }

    /**
     * Briefly ducks any other app's audio (music, video, etc.) while JARVIS is
     * actively listening or speaking, instead of a hard, jarring mute.
     */
    private fun requestDuck() {
        if (audioManager == null || focusRequest != null) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(noopFocusListener, mainHandler)
                .build()
            focusRequest = request
            audioManager.requestAudioFocus(request)
        } catch (e: Exception) { /* ignore — ducking is a nicety, not required */ }
    }

    private fun abandonDuck() {
        val request = focusRequest ?: return
        try {
            audioManager?.abandonAudioFocusRequest(request)
        } catch (e: Exception) { /* ignore */ }
        focusRequest = null
    }

    private fun handleHeardText(text: String) {
        if (text.isBlank()) {
            restartSoon(150)
            return
        }
        val lower = text.lowercase(Locale.ROOT)
        val wakeWordHeard = WAKE_WORD_VARIANTS.any { lower.contains(it) }
        if (wakeWordHeard) {
            // Strip the wake word, keep whatever the user asked after it.
            var command = lower
            WAKE_WORD_VARIANTS.forEach { command = command.replace(it, "") }
            command = command.trim(' ', ',', '.', '!', '?')
            onWakeResult?.invoke(command)
            // Don't auto-restart here — the app will restart listening once it's done
            // processing and speaking the reply, via onSpeakStateChanged(false).
        } else {
            // Not directed at JARVIS — stay quiet and keep listening.
            restartSoon(150)
        }
    }

    private fun restartSoon(delayMs: Long) {
        if (!continuousMode) return
        mainHandler.postDelayed({ startRecognizerCycle() }, delayMs)
    }

    /** Call this once the app is done handling a command, to resume always-on listening. */
    fun resumeListeningAfterReply() {
        if (continuousMode) mainHandler.post { startRecognizerCycle() }
    }

    fun speak(text: String) {
        requestDuck()
        val params = Bundle()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utterance")
    }

    fun destroy() {
        continuousMode = false
        unmuteMicBeep()
        abandonDuck()
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
    }

    companion object {
        // Common ways "Jarvis" gets misheard by the Turkish speech model.
        private val WAKE_WORD_VARIANTS = listOf(
            "jarvis", "carvis", "jarviz", "carviz", "carvız", "jarvız",
            "carvis'", "jarvis'"
        )
    }
}
