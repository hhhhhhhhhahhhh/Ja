package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class SpeechManager(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var turkishVoices: List<android.speech.tts.Voice> = emptyList()
    private var voiceIndex = 0

    private val mainHandler = Handler(Looper.getMainLooper())
    private var continuousMode = false
    private var isListeningNow = false
    private var isSpeakingNow = false
    private var isSessionStarting = false
    private var consecutiveErrorCount = 0

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var focusRequest: AudioFocusRequest? = null
    private val noopFocusListener = AudioManager.OnAudioFocusChangeListener { /* we don't need to react */ }

    // Callbacks used by continuous listening mode.
    private var onWakeResult: ((String) -> Unit)? = null
    private var onListeningStateChanged: ((Boolean) -> Unit)? = null
    private var onSpeakStateChanged: ((Boolean) -> Unit)? = null
    private var onErrorHeard: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
                turkishVoices = tts.voices
                    ?.filter { it.locale.language == "tr" }
                    ?.sortedBy { it.name }
                    .orEmpty()
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeakingNow = true
                onSpeakStateChanged?.invoke(true)
            }
            override fun onDone(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                abandonDuck()
                // Resume listening after JARVIS finishes talking, so it doesn't hear itself.
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
            override fun onError(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                abandonDuck()
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
        })
    }

    /** Cycles to the next available Turkish TTS voice and speaks a short confirmation. */
    fun cycleVoice(): String {
        if (turkishVoices.size <= 1) {
            speak("Bu cihazda değiştirebileceğim başka bir Türkçe ses yok.")
            return "Bu cihazda tek bir Türkçe ses seçeneği var."
        }
        voiceIndex = (voiceIndex + 1) % turkishVoices.size
        tts.voice = turkishVoices[voiceIndex]
        val label = "Ses değiştirildi, seçenek ${voiceIndex + 1} / ${turkishVoices.size}."
        speak(label)
        return label
    }

    /**
     * Starts always-on listening. [onWakeResult] only fires for utterances that
     * contain the wake word "jarvis" (already stripped out of the text). Every
     * other heard phrase is silently discarded and listening restarts automatically.
     */
    fun startContinuousListening(
        onWakeResult: (String) -> Unit,
        onListeningStateChanged: (Boolean) -> Unit,
        onSpeakStateChanged: (Boolean) -> Unit,
        onErrorHeard: (String) -> Unit
    ) {
        this.onWakeResult = onWakeResult
        this.onListeningStateChanged = onListeningStateChanged
        this.onSpeakStateChanged = onSpeakStateChanged
        this.onErrorHeard = onErrorHeard
        continuousMode = true
        startRecognizerCycle()
    }

    fun stopContinuousListening() {
        continuousMode = false
        isListeningNow = false
        isSessionStarting = false
        unmuteMicBeep()
        abandonDuck()
        recognizer?.stopListening()
    }

    private fun startRecognizerCycle() {
        if (!continuousMode || isSpeakingNow || isListeningNow || isSessionStarting) return

        // Fail fast with a clear signal instead of silently looping forever on
        // devices/profiles with no speech recognition service available.
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onErrorHeard?.invoke("Bu cihazda konuşma tanıma servisi bulunamadı.")
            return
        }

        isSessionStarting = true

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListeningNow = true
                isSessionStarting = false
                consecutiveErrorCount = 0
                onListeningStateChanged?.invoke(true)
                // The start "beep" already played by the time we get here; unmute
                // right away so the user's own voice is heard normally while talking.
                mainHandler.postDelayed({ unmuteMicBeep() }, 150)
            }

            override fun onResults(results: Bundle) {
                isListeningNow = false
                isSessionStarting = false
                onListeningStateChanged?.invoke(false)
                abandonDuck()
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                handleHeardText(text)
            }

            override fun onError(error: Int) {
                isListeningNow = false
                isSessionStarting = false
                onListeningStateChanged?.invoke(false)
                unmuteMicBeep()
                abandonDuck()

                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        // Normal in always-on mode — just listen again quietly.
                        consecutiveErrorCount = 0
                        restartSoon(150)
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        // Another recognition session is still winding down — back off
                        // a bit longer instead of hammering it and give up on this cycle.
                        restartSoon(1200)
                    }
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        onErrorHeard?.invoke("Mikrofon izni verilmediği için dinleyemiyorum.")
                    }
                    else -> {
                        consecutiveErrorCount++
                        if (consecutiveErrorCount >= 2) {
                            // The recognizer sometimes gets stuck after a few failures —
                            // recreate it from scratch rather than keep retrying the same instance.
                            recreateRecognizer()
                            consecutiveErrorCount = 0
                        }
                        restartSoon(900)
                    }
                }
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                // The "end" beep plays right as speech ends — mute it a beat before
                // the recognizer reports results/error.
                muteMicBeep()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            requestDuck()
            muteMicBeep()
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            isSessionStarting = false
            unmuteMicBeep()
            abandonDuck()
            restartSoon(800)
        }
    }

    private fun recreateRecognizer() {
        try { recognizer?.destroy() } catch (e: Exception) { /* ignore */ }
        recognizer = null
    }

    /**
     * Best-effort suppression of the system recognizer "start/stop listening" beep.
     * On stock Android these tones play on STREAM_MUSIC (not STREAM_SYSTEM), so both
     * are muted here for the widest device coverage. Requires MODIFY_AUDIO_SETTINGS.
     */
    private fun muteMicBeep() {
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
        } catch (e: Exception) { /* not all devices allow this — safe to ignore */ }
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
        } catch (e: Exception) { /* ignore */ }
    }

    private fun unmuteMicBeep() {
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) { /* ignore */ }
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) { /* ignore */ }
    }

    /**
     * Briefly ducks any other app's audio (music, video, etc.) while JARVIS is
     * actively listening or speaking — the same "lower the background audio while
     * I'm listening" behavior Gemini/Assistant use, instead of a hard, jarring mute.
     */
    private fun requestDuck() {
        if (audioManager == null || focusRequest != null) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(noopFocusListener, mainHandler)
                .build()
            focusRequest = request
            audioManager.requestAudioFocus(request)
        } catch (e: Exception) { /* ignore — ducking is a nicety, not required */ }
    }

    private fun abandonDuck() {
        val request = focusRequest ?: return
        try {
            audioManager?.abandonAudioFocusRequest(request)
        } catch (e: Exception) { /* ignore */ }
        focusRequest = null
    }

    private fun handleHeardText(text: String) {
        if (text.isBlank()) {
            restartSoon(150)
            return
        }
        val lower = text.lowercase(Locale.ROOT)
        val wakeWordHeard = WAKE_WORD_VARIANTS.any { lower.contains(it) }
        if (wakeWordHeard) {
            // Strip the wake word, keep whatever the user asked after it.
            var command = lower
            WAKE_WORD_VARIANTS.forEach { command = command.replace(it, "") }
            command = command.trim(' ', ',', '.', '!', '?')
            onWakeResult?.invoke(command)
            // Don't auto-restart here — the app will restart listening once it's done
            // processing and speaking the reply, via onSpeakStateChanged(false).
        } else {
            // Not directed at JARVIS — stay quiet and keep listening.
            restartSoon(150)
        }
    }

    private fun restartSoon(delayMs: Long) {
        if (!continuousMode) return
        mainHandler.postDelayed({ startRecognizerCycle() }, delayMs)
    }

    /** Call this once the app is done handling a command, to resume always-on listening. */
    fun resumeListeningAfterReply() {
        if (continuousMode) mainHandler.post { startRecognizerCycle() }
    }

    fun speak(text: String) {
        requestDuck()
        val params = Bundle()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utterance")
    }

    fun destroy() {
        continuousMode = false
        unmuteMicBeep()
        abandonDuck()
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
    }

    companion object {
        // Common ways "Jarvis" gets misheard by the Turkish speech model.
        private val WAKE_WORD_VARIANTS = listOf(
            "jarvis", "carvis", "jarviz", "carviz", "carvız", "jarvız",
            "carvis'", "jarvis'"
        )
    }
}
