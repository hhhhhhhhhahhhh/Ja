package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.ui.OrbView
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.launch

/**
 * JARVIS — API'siz sürüm + telefonda çalışan yerel AI + sürekli dinleme.
 * Uygulama açılır açılmaz mikrofon sürekli açık kalır; sadece "Jarvis" uyandırma
 * kelimesi geçen cümleler işlenir, geri kalan konuşmalar sessizce görmezden gelinir.
 * Ortadaki orb, o an ne yaptığını (dinliyor/düşünüyor/konuşuyor/hata) renkle gösterir.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var speechManager: SpeechManager
    private lateinit var adapter: ChatAdapter
    private lateinit var localLlm: LocalLlmClient
    private lateinit var orbView: OrbView

    private val messages = mutableListOf<ChatMessage>()
    private val permissionRequestCode = 42

    private val systemPrompt = "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    private val helpText = """
        Şunları deneyebilirsin (önce "Jarvis" de):
        • "Jarvis, Spotify aç", "Jarvis, Google aç"
        • "Jarvis, İstanbul'da hava durumu"
        • "Jarvis, pil durumu", "ram durumu", "depolama durumu", "saat kaç"
        • "Jarvis, Ali'ye whatsapp'tan merhaba yaz"
        • "Jarvis, böyle bir şarkı çal"
        • "Jarvis, 14:30'da toplantı hatırlat"
        • "Jarvis, sesi değiştir"
        Bunların dışındaki her şeyi telefonda çalışan yerel AI modeline soracağım.
    """.trimIndent()

    private val modelPickerLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        addMessage("Model dosyası kopyalanıyor, biraz sürebilir...", isUser = false)
        lifecycleScope.launch {
            val ok = localLlm.importModel(uri)
            addMessage(
                if (ok) "Yerel model hazır! Artık sabit komutlara uymayan her şeyi offline yanıtlayabilirim."
                else "Model dosyası okunamadı. Doğru .litertlm dosyasını seçtiğinden emin ol.",
                isUser = false
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        requestRuntimePermissions()

        speechManager = SpeechManager(this)
        localLlm = LocalLlmClient(this)

        orbView = findViewById(R.id.orbView)
        orbView.setState(OrbView.State.IDLE)

        val recycler = findViewById<RecyclerView>(R.id.chatRecycler)
        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<ImageButton>(R.id.sendButton)
        val micButton = findViewById<ImageButton>(R.id.micButton)
        val voiceChangeButton = findViewById<ImageButton>(R.id.voiceChangeButton)
        val selectModelButton = findViewById<ImageButton>(R.id.selectModelButton)

        addMessage("Merhaba! Ben JARVIS. Beni uyandırmak için önce \"Jarvis\" de. $helpText", isUser = false)
        if (!localLlm.isModelReady) {
            addMessage(
                "Serbest sohbet için bir yerel AI modeli seçmen gerekiyor. Yukarıdaki yükleme " +
                    "ikonuna dokunup, tarayıcından indirdiğin .litertlm model dosyasını seç.",
                isUser = false
            )
        }

        selectModelButton.setOnClickListener {
            modelPickerLauncher.launch(arrayOf("*/*"))
        }

        voiceChangeButton.setOnClickListener {
            val result = speechManager.cycleVoice()
            addMessage(result, isUser = false)
        }

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserMessage(text)
            }
        }

        // Mikrofon butonuna dokunmak artık sadece sürekli dinlemeyi tekrar başlatır
        // (izin verilmemişse ister, verilmişse zaten sürekli açık).
        micButton.setOnClickListener {
            if (!hasRecordAudioPermission()) {
                requestRuntimePermissions()
            } else {
                startAlwaysOnListening()
            }
        }

        if (hasRecordAudioPermission()) {
            android.os.Handler(mainLooper).postDelayed({ startAlwaysOnListening() }, 400)
        }
    }

    private fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    /** Starts always-on listening: only reacts to phrases containing the "Jarvis" wake word. */
    private fun startAlwaysOnListening() {
        speechManager.startContinuousListening(
            onWakeResult = { command -> onWakeWordHeard(command) },
            onListeningStateChanged = { listening ->
                runOnUiThread {
                    if (listening) orbView.setState(OrbView.State.LISTENING)
                }
            },
            onSpeakStateChanged = { speaking ->
                runOnUiThread {
                    orbView.setState(if (speaking) OrbView.State.SPEAKING else OrbView.State.LISTENING)
                }
            },
            onErrorHeard = { /* always-on mode stays quiet on recognition errors */ }
        )
    }

    private fun onWakeWordHeard(command: String) {
        runOnUiThread {
            if (command.isBlank()) {
                // User just said "Jarvis" with nothing after it.
                orbView.setState(OrbView.State.SPEAKING)
                addMessage("Jarvis", isUser = true)
                val reply = "Efendim?"
                addMessage(reply, isUser = false)
                speechManager.speak(reply)
            } else {
                handleUserMessage(command)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode && hasRecordAudioPermission()) {
            startAlwaysOnListening()
        }
    }

    private fun handleUserMessage(text: String) {
        addMessage(text, isUser = true)
        orbView.setState(OrbView.State.THINKING)

        val normalized = text.trim().lowercase()
        if (normalized.contains("sesi değiştir") || normalized.contains("sesini değiştir") ||
            normalized.contains("ses değiştir")
        ) {
            val reply = speechManager.cycleVoice()
            addMessage(reply, isUser = false)
            return
        }

        val localResult = LocalCommandParser.tryHandle(this, normalized)
        if (localResult != null) {
            addMessage(localResult, isUser = false)
            speechManager.speak(localResult)
            return
        }

        if (!localLlm.isModelReady) {
            val msg = "Bunu anlayamadım ve henüz yerel model seçilmedi. $helpText"
            addMessage(msg, isUser = false)
            speechManager.speak("Bunu anlayamadım.")
            return
        }

        lifecycleScope.launch {
            val reply = localLlm.reply(systemPrompt, text)
            runOnUiThread {
                addMessage(reply, isUser = false)
                speechManager.speak(reply)
            }
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        adapter.addMessage(ChatMessage(text, isUser))
        findViewById<RecyclerView>(R.id.chatRecycler).scrollToPosition(messages.size - 1)
    }

    private fun requestRuntimePermissions() {
        val needed = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS
        ).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequestCode)
        }
    }

    override fun onDestroy() {
        if (::speechManager.isInitialized) {
            speechManager.destroy()
        }
        super.onDestroy()
    }
}
