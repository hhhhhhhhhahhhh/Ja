package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class SpeechManager(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var turkishVoices: List<android.speech.tts.Voice> = emptyList()
    private var voiceIndex = 0

    private val mainHandler = Handler(Looper.getMainLooper())
    private var continuousMode = false
    private var isListeningNow = false
    private var isSpeakingNow = false

    // Callbacks used by continuous listening mode.
    private var onWakeResult: ((String) -> Unit)? = null
    private var onListeningStateChanged: ((Boolean) -> Unit)? = null
    private var onSpeakStateChanged: ((Boolean) -> Unit)? = null
    private var onErrorHeard: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
                turkishVoices = tts.voices
                    ?.filter { it.locale.language == "tr" }
                    ?.sortedBy { it.name }
                    .orEmpty()
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeakingNow = true
                onSpeakStateChanged?.invoke(true)
            }
            override fun onDone(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                // Resume listening after JARVIS finishes talking, so it doesn't hear itself.
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
            override fun onError(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
        })
    }

    /** Cycles to the next available Turkish TTS voice and speaks a short confirmation. */
    fun cycleVoice(): String {
        if (turkishVoices.size <= 1) {
            speak("Bu cihazda değiştirebileceğim başka bir Türkçe ses yok.")
            return "Bu cihazda tek bir Türkçe ses seçeneği var."
        }
        voiceIndex = (voiceIndex + 1) % turkishVoices.size
        tts.voice = turkishVoices[voiceIndex]
        val label = "Ses değiştirildi, seçenek ${voiceIndex + 1} / ${turkishVoices.size}."
        speak(label)
        return label
    }

    /**
     * Starts always-on listening. [onWakeResult] only fires for utterances that
     * contain the wake word "jarvis" (already stripped out of the text). Every
     * other heard phrase is silently discarded and listening restarts automatically.
     */
    fun startContinuousListening(
        onWakeResult: (String) -> Unit,
        onListeningStateChanged: (Boolean) -> Unit,
        onSpeakStateChanged: (Boolean) -> Unit,
        onErrorHeard: (String) -> Unit
    ) {
        this.onWakeResult = onWakeResult
        this.onListeningStateChanged = onListeningStateChanged
        this.onSpeakStateChanged = onSpeakStateChanged
        this.onErrorHeard = onErrorHeard
        continuousMode = true
        startRecognizerCycle()
    }

    fun stopContinuousListening() {
        continuousMode = false
        isListeningNow = false
        recognizer?.stopListening()
    }

    private fun startRecognizerCycle() {
        if (!continuousMode || isSpeakingNow) return

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListeningNow = true
                onListeningStateChanged?.invoke(true)
            }

            override fun onResults(results: Bundle) {
                isListeningNow = false
                onListeningStateChanged?.invoke(false)
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                handleHeardText(text)
            }

            override fun onError(error: Int) {
                isListeningNow = false
                onListeningStateChanged?.invoke(false)
                // No-speech / timeout is normal in always-on mode — just listen again quietly.
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    restartSoon(150)
                } else {
                    restartSoon(800)
                }
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            restartSoon(800)
        }
    }

    private fun handleHeardText(text: String) {
        if (text.isBlank()) {
            restartSoon(150)
            return
        }
        val lower = text.lowercase()
        if (lower.contains("jarvis") || lower.contains("carvis") || lower.contains("jarviz")) {
            // Strip the wake word, keep whatever the user asked after it.
            val command = lower
                .replace("jarvis", "")
                .replace("carvis", "")
                .replace("jarviz", "")
                .trim(' ', ',', '.', '!', '?')
            onWakeResult?.invoke(command)
            // Don't auto-restart here — the app will restart listening once it's done
            // processing and speaking the reply, via onSpeakStateChanged(false).
        } else {
            // Not directed at JARVIS — stay quiet and keep listening.
            restartSoon(150)
        }
    }

    private fun restartSoon(delayMs: Long) {
        if (!continuousMode) return
        mainHandler.postDelayed({ startRecognizerCycle() }, delayMs)
    }

    /** Call this once the app is done handling a command, to resume always-on listening. */
    fun resumeListeningAfterReply() {
        if (continuousMode) mainHandler.post { startRecognizerCycle() }
    }

    fun speak(text: String) {
        val params = Bundle()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utterance")
    }

    fun destroy() {
        continuousMode = false
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
    }
}
