package com.jarvis.assistant.core

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.R

class ChatAdapter(private val items: MutableList<ChatMessage>) :
    RecyclerView.Adapter<ChatAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val root: View = view
        val text: android.widget.TextView = view.findViewById(R.id.messageText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val msg = items[position]
        holder.text.text = msg.text
        val container = holder.text.parent as android.widget.LinearLayout
        if (msg.isUser) {
            container.gravity = Gravity.END
            holder.text.setBackgroundResource(R.drawable.bg_bubble_user)
        } else {
            container.gravity = Gravity.START
            holder.text.setBackgroundResource(R.drawable.bg_bubble_jarvis)
        }
        holder.text.setTextColor(ContextCompat.getColor(holder.text.context, R.color.jarvis_text))
    }

    override fun getItemCount(): Int = items.size

    fun addMessage(message: ChatMessage) {
        items.add(message)
        notifyItemInserted(items.size - 1)
    }
}
