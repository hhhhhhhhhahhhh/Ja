package com.jarvis.assistant.ai

import com.jarvis.assistant.core.ActionRouter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Talks to Groq's OpenAI-compatible Chat Completions endpoint using function calling.
 * Groq's free tier needs no credit card and has much higher daily limits than
 * Gemini's free tier or xAI's pay-as-you-go API.
 */
class GroqClient(
    private val apiKey: String,
    private val actionRouter: ActionRouter,
    private val systemPrompt: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val model = "llama-3.3-70b-versatile"
    private val endpoint = "https://api.groq.com/openai/v1/chat/completions"

    /** Full running conversation, OpenAI "messages" format. Starts with the system prompt. */
    private val history = JSONArray().apply {
        put(JSONObject().put("role", "system").put("content", systemPrompt))
    }

    suspend fun send(userText: String): String = withContext(Dispatchers.IO) {
        history.put(JSONObject().put("role", "user").put("content", userText))

        repeat(MAX_TOOL_HOPS) {
            val result = callApiWithRetry()
                ?: return@withContext "API kotasına ulaşıldı. Birkaç dakika sonra tekrar dener misin?"

            val message = result.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                ?: return@withContext "Yanıt alınamadı."

            val toolCalls = message.optJSONArray("tool_calls")
            val content = message.optString("content", "")

            // Record the assistant's turn (including any tool calls) in history.
            history.put(message)

            if (toolCalls == null || toolCalls.length() == 0) {
                return@withContext content.ifBlank { "..." }
            }

            for (i in 0 until toolCalls.length()) {
                val call = toolCalls.getJSONObject(i)
                val callId = call.getString("id")
                val function = call.getJSONObject("function")
                val fnName = function.getString("name")
                val argsRaw = function.optString("arguments", "{}")
                val args = try { JSONObject(argsRaw) } catch (e: Exception) { JSONObject() }

                val resultText = actionRouter.execute(fnName, args)

                history.put(
                    JSONObject()
                        .put("role", "tool")
                        .put("tool_call_id", callId)
                        .put("content", resultText)
                )
            }
        }

        "İşlemi tamamlayamadım, tekrar dener misin?"
    }

    private suspend fun callApiWithRetry(): JSONObject? {
        val first = callApiRaw()
        if (first.code != 429) return first.body

        val waitSeconds = parseRetrySeconds(first.rawError).coerceIn(1.0, 15.0)
        delay((waitSeconds * 1000).toLong())

        val second = callApiRaw()
        return if (second.code == 429) null else second.body
    }

    private data class ApiCallResult(val code: Int, val body: JSONObject?, val rawError: String)

    private fun callApiRaw(): ApiCallResult {
        val body = JSONObject().apply {
            put("model", model)
            put("messages", history)
            put("tools", OpenAiToolDeclarations.all)
            put("tool_choice", "auto")
        }

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                return ApiCallResult(resp.code, null, text)
            }
            return ApiCallResult(resp.code, JSONObject(text), text)
        }
    }

    private fun parseRetrySeconds(errorBody: String): Double {
        return try {
            Regex("retry.*?([0-9.]+)").find(errorBody)?.groupValues?.get(1)?.toDouble() ?: 5.0
        } catch (e: Exception) {
            5.0
        }
    }

    companion object {
        private const val MAX_TOOL_HOPS = 5
    }
}
