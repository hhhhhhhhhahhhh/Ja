package com.jarvis.assistant.crash

import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Shows the full crash stack trace on screen so it can be screenshotted and shared. */
class CrashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val trace = intent.getStringExtra("trace") ?: "Hata bilgisi alınamadı."

        val textView = TextView(this).apply {
            text = "JARVIS ÇÖKTÜ — bu ekranın görüntüsünü paylaş:\n\n$trace"
            setPadding(24, 48, 24, 48)
            setTextIsSelectable(true)
            textSize = 12f
        }
        val scroll = ScrollView(this).apply { addView(textView) }
        setContentView(scroll)
    }
}
