package com.jarvis.assistant.ai

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/**
 * Runs a small language model directly on the phone via Google's official
 * MediaPipe LLM Inference API. No internet needed after the model file is
 * imported once, no API key, no quota. This is a plain chat fallback — it
 * does NOT do tool/function calling; fixed commands are still handled by
 * LocalCommandParser before this is ever reached.
 *
 * The model file (a Gemma ".task" bundle) is NOT downloaded automatically,
 * because the small Gemma models on Hugging Face require accepting a license
 * on your own account first. Embedding a personal access token in the app's
 * public source would leak it. Instead, the user downloads the file once in
 * their own browser (already logged in / license already accepted there),
 * and picks it via the system file picker, which this class then copies into
 * the app's private storage.
 */
class LocalLlmClient(private val context: Context) {

    private val modelFile: File
        get() = File(context.filesDir, MODEL_FILENAME)

    val isModelReady: Boolean
        get() = modelFile.exists() && modelFile.length() > 20_000_000L

    private var llmInference: LlmInference? = null
    private var session: LlmInferenceSession? = null

    /** Copies a user-picked .task model file into private storage. Returns true on success. */
    suspend fun importModel(sourceUri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.filesDir, "$MODEL_FILENAME.part")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                tempFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return@withContext false
            tempFile.renameTo(modelFile)
            llmInference = null
            session = null
            isModelReady
        } catch (e: Exception) {
            false
        }
    }

    private fun ensureLoaded() {
        if (llmInference != null) return
        if (!isModelReady) return

        val inference = LlmInference.createFromOptions(
            context,
            LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(512)
                .build()
        )
        llmInference = inference
        session = LlmInferenceSession.createFromOptions(
            inference,
            LlmInferenceSession.LlmInferenceSessionOptions.builder()
                .setTopK(40)
                .setTemperature(0.8f)
                .build()
        )
    }

    suspend fun reply(systemPrompt: String, userText: String): String = withContext(Dispatchers.IO) {
        if (!isModelReady) return@withContext "Yerel model henüz seçilmedi."
        try {
            ensureLoaded()
        } catch (e: Exception) {
            return@withContext "Model yüklenemedi: ${e.message}"
        }
        val activeSession = session ?: return@withContext "Model yüklenemedi."

        try {
            suspendCancellableCoroutine { cont ->
                val builder = StringBuilder()
                activeSession.addQueryChunk("$systemPrompt\n\nKullanıcı: $userText\nJARVIS:")
                activeSession.generateResponseAsync { partialResult, done ->
                    builder.append(partialResult)
                    if (done && cont.isActive) {
                        cont.resume(builder.toString().ifBlank { "..." })
                    }
                }
            }
        } catch (e: Exception) {
            "Yerel model hatası: ${e.message}"
        }
    }

    companion object {
        private const val MODEL_FILENAME = "jarvis-local-model.task"
    }
}
