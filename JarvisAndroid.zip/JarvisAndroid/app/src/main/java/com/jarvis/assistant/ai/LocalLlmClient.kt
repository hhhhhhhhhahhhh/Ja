package com.jarvis.assistant.ai

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/**
 * Runs a small language model directly on the phone via Google's official
 * MediaPipe LLM Inference API. No internet needed after the model file is
 * imported once, no API key, no quota. This is a plain chat fallback — it
 * does NOT do tool/function calling; fixed commands are still handled by
 * LocalCommandParser before this is ever reached.
 *
 * Each call is stateless (no persisted session): a tiny model like Gemma 270M
 * gets confused fast if you keep feeding it a growing, awkwardly-formatted
 * history, so every turn gets a clean prompt using Gemma's chat template.
 */
class LocalLlmClient(private val context: Context) {

    private val modelFile: File
        get() = File(context.filesDir, MODEL_FILENAME)

    val isModelReady: Boolean
        get() = modelFile.exists() && modelFile.length() > 20_000_000L

    private var llmInference: LlmInference? = null

    /** Copies a user-picked .task model file into private storage. Returns true on success. */
    suspend fun importModel(sourceUri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.filesDir, "$MODEL_FILENAME.part")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                tempFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return@withContext false
            tempFile.renameTo(modelFile)
            llmInference = null
            isModelReady
        } catch (e: Exception) {
            false
        }
    }

    private fun ensureLoaded() {
        if (llmInference != null) return
        if (!isModelReady) return

        llmInference = LlmInference.createFromOptions(
            context,
            LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(512)
                .build()
        )
    }

    suspend fun reply(systemPrompt: String, userText: String): String = withContext(Dispatchers.IO) {
        if (!isModelReady) return@withContext "Yerel model henüz seçilmedi."
        try {
            ensureLoaded()
        } catch (e: Exception) {
            return@withContext "Model yüklenemedi: ${e.message}"
        }
        val inference = llmInference ?: return@withContext "Model yüklenemedi."

        // Gemma's expected chat template — feeding raw text without this is what
        // was causing garbled, repeating replies.
        val prompt = "<start_of_turn>user\n$systemPrompt\n\n$userText<end_of_turn>\n<start_of_turn>model\n"

        try {
            suspendCancellableCoroutine { cont ->
                val builder = StringBuilder()
                inference.generateResponseAsync(prompt) { partialResult, done ->
                    builder.append(partialResult)
                    if (done && cont.isActive) {
                        cont.resume(builder.toString().ifBlank { "..." })
                    }
                }
            }
        } catch (e: Exception) {
            "Yerel model hatası: ${e.message}"
        }
    }

    companion object {
        private const val MODEL_FILENAME = "jarvis-local-model.task"
    }
}
